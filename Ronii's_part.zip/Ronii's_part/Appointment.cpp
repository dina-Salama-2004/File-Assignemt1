#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <strstream>

using namespace std;
//150
//3 0
//5 9
//6 18
//4 0
void Insert_ID_Sorted(char id[] , short offset, int &count_id){
    fstream primary("primary_Index.txt", ios::out | ios::binary |ios::in );
    int New_App_id = 0;
    for(int i=0 ; id[i] != '\0'; i++){
        New_App_id *=10;
        New_App_id +=(id[i] - '0');
    }
    int existing_id = 0;
    short off = 0;
    bool find_position = false;

    if(count_id == 0){
        primary.write((char*)&New_App_id, sizeof(New_App_id));
        primary.write((char*)&offset, sizeof(offset));
        count_id++;
        cout << New_App_id << offset << "the only one--------------" << endl;
    }
    else{
        primary.read((char*)&existing_id, sizeof(existing_id));
        while(primary.good()){
            if(existing_id > New_App_id){
                find_position= true;
                primary.seekg(-4,ios::cur);
                off = primary.tellg();
                break;
            }
            primary.seekg(2, ios::cur);
            primary.read((char*)&existing_id, sizeof(existing_id));
        }
        primary.close();
        primary.open("primary_Index.txt", ios::out | ios::binary |ios::in  );

        if(!find_position){
            primary.seekg(count_id*6,ios::beg);
            primary.write((char*)&New_App_id, sizeof(int));
            primary.write((char*)&offset, sizeof(short));
            count_id++;
            cout << New_App_id << offset << "--------------" << endl;


        }
        else{
            primary.seekg((count_id-1)*6);
            int endNum;
            short endOf;
            primary.read((char*)&endNum, sizeof (endNum));
            primary.read((char*)&endOf, sizeof (endOf));
            primary.seekg(off);

            while(primary.good()){//1 2 -3 -3 4 5
                int num1;short num1_Of;
                int num2;short num2_Of;
                primary.read((char*)&num1, sizeof (num1));
                primary.read((char*)&num1_Of, sizeof (num1_Of));

                primary.read((char*)&num2, sizeof (num2));
                primary.read((char*)&num2_Of, sizeof (num2_Of));

                primary.seekg(-6,ios::cur);
                primary.write((char*)&num1, sizeof (num1));
                primary.write((char*)&num1_Of, sizeof (num1_Of));
            }
            primary.close();
            primary.open("primary_Index.txt", ios::out | ios::binary |ios::in );

            primary.seekg(0,ios::end);
            primary.write((char*)&endNum, sizeof (endNum));
            primary.write((char*)&endOf, sizeof (endOf));
            primary.seekg(off);
            primary.write((char*)&New_App_id, sizeof (New_App_id));
            primary.write((char*)&offset, sizeof (off));
            count_id++;
            cout << New_App_id << offset << "--------------" << endl;
        }
    }

    primary.close();
}
class Appointment{
public:
    char Appointment_ID[15];
    char Appointment_Date[30];
    char Doctor_ID [15];

    const static int maxRecordSize = 1000;
    void writeAppointment(fstream &file, Appointment &s){
        char record [maxRecordSize];
        strcpy(record,s.Appointment_ID);
        strcat(record, "|");
        strcat(record, s.Appointment_Date);
        strcat(record,"|");
        strcat(record, s.Doctor_ID);
        strcat(record,"|");

        short length = strlen(record);


        file.write((char*)&length,sizeof(length));
        file.write(record, length);
    }
    void readAppointment (fstream &file, Appointment &s){
        short length;
        file.read((char*) &length, sizeof(length));
        char* record = new char[length];

        file.read(record, length);

        istrstream strbuff(record);
        strbuff>>s;
    }
    friend istream & operator >>(istream& file, Appointment &s){
        file.getline(s.Appointment_ID, 15, '|');
        file.getline(s.Appointment_Date, 30, '|');
        file.getline(s.Doctor_ID, 15, '|');
        return file;
    }

};
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int count_id = 0;
    fstream file("Appointment.txt", ios::out|ios::trunc);
    cout<<"enter # of Appointment u want to enter"<<endl;
    int count;
    cin>>count;
    cin.ignore();
    Appointment record;
    for(int i=0;i<count;i++){
        cout<<"id: "<<endl;
        cin>>record.Appointment_ID;
        cout<<"data:"<<endl;
        cin.ignore();
        cin.getline(record.Appointment_Date, 30);
        cout<<"doctorID: "<<endl;
        cin>>record.Doctor_ID;
        cout<< "offset = "<<file.tellp()<<endl;
        Insert_ID_Sorted(record.Appointment_ID,file.tellp(), count_id);
        record.writeAppointment(file, record);

    }
    file.close();
//
    file.open("Appointment.txt", ios::in|ios::binary);
    Appointment s2;
    for(int i=0;i<count;i++){
        s2.readAppointment(file, s2);
        cout << "id: " << s2.Appointment_ID << endl;
        cout << "data: " << s2.Appointment_Date << endl;
        cout << "doctorID: " << s2.Doctor_ID << endl;
    }

    file.close();








    return 0;
}
