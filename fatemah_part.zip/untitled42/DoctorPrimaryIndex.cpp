#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <strstream>

using namespace std;

class Doctor{
public:
    int ID ;
    short offset;

};
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    fstream file;
    file.open("doctor_primary_Index.txt", ios::in|ios::binary);
    Doctor s2;
    while(file.read((char*)&s2.ID,sizeof (s2.ID))&&
    file.read((char*)&s2.offset,sizeof (s2.offset))){
        cout << "ID = "<< s2.ID << " off = " << s2.offset <<endl;
    }
    file.close();








    return 0;
}
