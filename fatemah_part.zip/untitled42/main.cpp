
#include <bits/stdc++.h>//------------ origin
#include <iostream>
#include <fstream>
#include <strstream>

using namespace std;

void Insert_ID_Sorted(char id[], short offset, int &count_id) {
    fstream primary("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);
    int New_Doctor_id = 0;
    for (int i = 0; id[i] != '\0'; i++) {
        New_Doctor_id *= 10;
        New_Doctor_id += (id[i] - '0');
    }

    int existing_id = 0;
    short off = 0;
    bool find_position = false;

    if (count_id == 0) {
        primary.write((char *)&New_Doctor_id, sizeof(New_Doctor_id));
        primary.write((char *)&offset, sizeof(offset));
        count_id++;
    } else {
        primary.read((char *)&existing_id, sizeof(existing_id));
        while (primary.good()) {
            if (existing_id > New_Doctor_id) {
                find_position = true;
                primary.seekg(-4, ios::cur);
                off = primary.tellg();
                break;
            }
            primary.seekg(2, ios::cur);
            primary.read((char *)&existing_id, sizeof(existing_id));
        }
        primary.close();
        primary.open("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);

        if (!find_position) {
            primary.seekg(count_id * 6, ios::beg);
            primary.write((char *)&New_Doctor_id, sizeof(int));
            primary.write((char *)&offset, sizeof(short));
            count_id++;
        } else {
            primary.seekg((count_id - 1) * 6);
            int endNum;
            short endOf;
            primary.read((char *)&endNum, sizeof(endNum));
            primary.read((char *)&endOf, sizeof(endOf));
            primary.seekg(off);

            while (primary.good()) {
                int num1;
                short num1_Of;
                int num2;
                short num2_Of;
                primary.read((char *)&num1, sizeof(num1));
                primary.read((char *)&num1_Of, sizeof(num1_Of));

                primary.read((char *)&num2, sizeof(num2));
                primary.read((char *)&num2_Of, sizeof(num2_Of));

                primary.seekg(-6, ios::cur);
                primary.write((char *)&num1, sizeof(num1));
                primary.write((char *)&num1_Of, sizeof(num1_Of));
            }
            primary.close();
            primary.open("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);

            primary.seekg(0, ios::end);
            primary.write((char *)&endNum, sizeof(endNum));
            primary.write((char *)&endOf, sizeof(endOf));
            primary.seekg(off);
            primary.write((char *)&New_Doctor_id, sizeof(New_Doctor_id));
            primary.write((char *)&offset, sizeof(off));
            count_id++;
        }
    }

    primary.close();
}

class Doctor {
public:
    char Doctor_ID[15];
    char Doctor_Name[30];
    char Doctor_Address[30];

    const static int maxRecordSize = 1000;

    void writeDoctor(fstream &file, Doctor &doc) {
        char record[maxRecordSize];
        strcpy(record, doc.Doctor_ID);
        strcat(record, "|");
        strcat(record, doc.Doctor_Name);
        strcat(record, "|");
        strcat(record, doc.Doctor_Address);
        strcat(record, "|");

        short length = strlen(record);
        file.write((char*)&length, sizeof(length));
        file.write(record, length);
    }

    void readDoctor(fstream &file, Doctor &doc) {
        short length;
        file.read((char *)&length, sizeof(length));
        char *record = new char[length];

        file.read(record, length);

        istrstream strbuff(record);
        strbuff >> doc;
      // delete[] record;
    }

    friend istream &operator>>(istream &file, Doctor &doc) {
        file.getline(doc.Doctor_ID, 15, '|');
        file.getline(doc.Doctor_Name, 30, '|');
        file.getline(doc.Doctor_Address, 30, '|');
        return file;
    }
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int count_id = 0;
    fstream file("Doctor.txt", ios::out | ios::trunc);

    cout <<"Enter number of doctors to add: "<<endl;
    int count;
    cin >> count;
    cin.ignore();

    Doctor record;
    for (int i = 0; i < count; i++) {
        cout << "Doctor ID: "<<endl;
        cin >> record.Doctor_ID;
        cout << "Doctor Name: "<<endl;
        cin.ignore();
        cin.getline(record.Doctor_Name, 30);
        cout << "Doctor Address: "<<endl;
        cin.getline(record.Doctor_Address, 30);

        cout << "Offset = " << file.tellp() << endl;
        Insert_ID_Sorted(record.Doctor_ID, file.tellp(), count_id);
        record.writeDoctor(file, record);
    }
    file.close();

    file.open("Doctor.txt", ios::in | ios::binary);
    Doctor doc;
    for (int i = 0; i < count; i++) {
        doc.readDoctor(file, doc);
        cout << "Doctor ID: " << doc.Doctor_ID << endl;
        cout << "Doctor Name: " << doc.Doctor_Name << endl;
        cout << "Doctor Address: " << doc.Doctor_Address << endl;
    }

    file.close();


    return 0;
}
