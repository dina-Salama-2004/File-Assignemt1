#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>
#include <strstream>

using namespace std;


// Rana part   primary index
int getRecordCount(const char* filename, int recordSize) {
    fstream file(filename, ios::binary | ios::in);
    if (!file.is_open()) {
        cout << "File not found: " << filename << endl;
        return 0;
    }
    file.seekg(0, ios::end);
    int fileSize = file.tellg();
    file.close();
    return fileSize / recordSize;
}
void Insert_Doctor_ID_Sorted(char id[], short offset, int &count_id) {
    fstream primary("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);
    int New_Doctor_id = 0;
    for (int i = 0; id[i] != '\0'; i++) {
        New_Doctor_id *= 10;
        New_Doctor_id += (id[i] - '0');
    }

    int existing_id = 0;
    short off = 0;
    bool find_position = false;

    if (count_id == 0) {
        primary.write((char *)&New_Doctor_id, sizeof(New_Doctor_id));
        primary.write((char *)&offset, sizeof(offset));
        count_id++;
    } else {
        primary.read((char *)&existing_id, sizeof(existing_id));
        while (primary.good()) {
            if (existing_id > New_Doctor_id) {
                find_position = true;
                primary.seekg(-4, ios::cur);
                off = primary.tellg();
                break;
            }
            primary.seekg(2, ios::cur);
            primary.read((char *)&existing_id, sizeof(existing_id));
        }
        primary.close();
        primary.open("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);

        if (!find_position) {
            primary.seekg(count_id * 6, ios::beg);
            primary.write((char *)&New_Doctor_id, sizeof(int));
            primary.write((char *)&offset, sizeof(short));
            count_id++;
        } else {
            primary.seekg((count_id - 1) * 6);
            int endNum;
            short endOf;
            primary.read((char *)&endNum, sizeof(endNum));
            primary.read((char *)&endOf, sizeof(endOf));
            primary.seekg(off);
            while (primary.good()) {
                int num1;
                short num1_Of;
                int num2;
                short num2_Of;
                primary.read((char *)&num1, sizeof(num1));
                primary.read((char *)&num1_Of, sizeof(num1_Of));

                primary.read((char *)&num2, sizeof(num2));
                primary.read((char *)&num2_Of, sizeof(num2_Of));

                primary.seekg(-6, ios::cur);
                primary.write((char *)&num1, sizeof(num1));
                primary.write((char *)&num1_Of, sizeof(num1_Of));
            }
            primary.close();
            primary.open("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);
            primary.seekg(0, ios::end);
            primary.write((char *)&endNum, sizeof(endNum));
            primary.write((char *)&endOf, sizeof(endOf));
            primary.seekg(off);
            primary.write((char *)&New_Doctor_id, sizeof(New_Doctor_id));
            primary.write((char *)&offset, sizeof(off));
            count_id++;
        }
    }

    primary.close();
}
class Appointment {
public:
    char Appointment_ID[15];
    char Appointment_Date[30];
    char Doctor_ID[15];

    const static int maxRecordSize = 1000;

    void writeAppointment(fstream &file, Appointment &s) {
        char record[maxRecordSize];
        strcpy(record, s.Appointment_ID);
        strcat(record, "|");
        strcat(record, s.Appointment_Date);
        strcat(record, "|");
        strcat(record, s.Doctor_ID);
        strcat(record, "|");

        short length = strlen(record);

        file.write((char*)&length, sizeof(length));
        file.write(record, length);
    }

    void readAppointment(fstream &file, Appointment &s) {
        short length;
        file.read((char*)&length, sizeof(length));
        char* record = new char[length];
        file.read(record, length);

        istrstream strbuff(record);
        strbuff >> s;
        delete[] record;
    }

    friend istream& operator>>(istream& file, Appointment &s) {
        file.getline(s.Appointment_ID, 15, '|');
        file.getline(s.Appointment_Date, 30, '|');
        file.getline(s.Doctor_ID, 15, '|');
        return file;
    }
};

//secodary index on id
void displaySecondary_DoctorId() {
    fstream DoctorSec("SecondaryIndexForDoctor.txt", ios::binary | ios::in);
    if (!DoctorSec.is_open()) {
        cout << "Secondary Index file not found.\n";
        return;
    }

    char doctorID[15];
    short linkedListPointer;

    while (DoctorSec.read(doctorID, 15)) {
        DoctorSec.read((char*)&linkedListPointer, sizeof(linkedListPointer));
        cout << "Doctor ID: " << doctorID << ", Linked List Pointer: " << linkedListPointer << endl;
    }
    DoctorSec.close();
}
void addToLinkedList_DoctorId(const char *Doctor_ID, const char *Appointment_ID) {
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in | ios::out);
    if (!DoctorLink.is_open()) {
        cout << "Error opening linked list file." << endl;
        return;
    }
    DoctorLink.seekg(0, ios::end);
    DoctorLink.write(Doctor_ID, 15);
    DoctorLink.write(Appointment_ID, 15);
    short nega = -1;
    DoctorLink.write((char*)&nega, sizeof(nega));
    DoctorLink.close();
}
void insert_secondary_DoctorId(char Doctor_ID[15], char Appointment_ID[15]) {
    fstream DoctorSec("SecondaryIndexForDoctor.txt", ios::binary | ios::in | ios::out);
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in | ios::out);

    char temp[15];
    short linkedListPointer;
    int totalEntries = getRecordCount("SecondaryIndexForDoctor.txt", 17);

    // Binary search for the doctor ID
    bool found = false;
    int insertPosition = totalEntries;
    for (int i = 0; i < totalEntries; i++) {
        DoctorSec.seekg(i * 17, ios::beg);
        DoctorSec.read(temp, 15);
        if (strcmp(temp, Doctor_ID) > 0) {
            insertPosition = i;
            found = false;
            break;
        } else if (strcmp(temp, Doctor_ID) == 0) {
            found = true;
            break;
        }
    }

    if (!found) {
        // Shift records to the right to make room for the new record
        for (int i = totalEntries - 1; i >= insertPosition; i--) {
            DoctorSec.seekg(i * 17, ios::beg);
            char existingDoctorID[15];
            short existingPointer;
            DoctorSec.read(existingDoctorID, 15);
            DoctorSec.read((char*)&existingPointer, sizeof(existingPointer));

            DoctorSec.seekp((i + 1) * 17, ios::beg);
            DoctorSec.write(existingDoctorID, 15);
            DoctorSec.write((char*)&existingPointer, sizeof(existingPointer));
        }

        // Insert the new Doctor ID and pointer at the correct position
        DoctorSec.seekp(insertPosition * 17, ios::beg);
        DoctorSec.write(Doctor_ID, 15);
        linkedListPointer = getRecordCount("LLIndexForDoctor.txt", 32);
        DoctorSec.write((char*)&linkedListPointer, sizeof(linkedListPointer));

        // Add the new appointment to the linked list
        addToLinkedList_DoctorId(Doctor_ID, Appointment_ID);
    }
    else
    {



        // Doctor ID exists, update the linked list
        DoctorLink.seekg(0, ios::end);
        int fileSize = DoctorLink.tellg();
        int entrySize = 32;  // Size of each record (doctorID + appointmentID + nextPointer)
        int recordCount = fileSize / entrySize;

        for (int i = recordCount - 1; i >= 0; i--) {
            DoctorLink.seekg(i * entrySize, ios::beg);
            char doctorID[15];
            char appointmentID[15];
            short nextPointer;

            DoctorLink.read(doctorID, 15);
            DoctorLink.read(appointmentID, 15);
            DoctorLink.read((char*)&nextPointer, sizeof(nextPointer));

            if (strcmp(doctorID, Doctor_ID) == 0) {
                short newPointer = recordCount; // Update to the next appointment record
                DoctorLink.seekp(i * entrySize + 30, ios::beg);
                DoctorLink.write((char*)&newPointer, sizeof(newPointer));
                break;
            }
        }

        // Add the appointment to the linked list
        addToLinkedList_DoctorId(Doctor_ID, Appointment_ID);


    }



    DoctorSec.close();
    DoctorLink.close();
}

void write_Number_of_appointment() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int count_id = 0;
    fstream file("Appointment.txt", ios::out | ios::trunc);
    cout << "Enter # of Appointment you want to enter" << endl;
    int count;
    cin >> count;
    cin.ignore();
    Appointment record;
    for (int i = 0; i < count; i++) {
        cout << "ID: " << endl;
        cin >> record.Appointment_ID;
        cout << "Date:" << endl;
        cin.ignore();
        cin.getline(record.Appointment_Date, 30);
        cout << "Doctor ID: " << endl;
        cin >> record.Doctor_ID;
        cout << "Offset = " << file.tellp() << endl;
        Insert_Doctor_ID_Sorted(record.Appointment_ID, file.tellp(), count_id);
        insert_secondary_DoctorId(record.Doctor_ID, record.Appointment_ID);
        record.writeAppointment(file, record);
    }
    file.close();

    file.open("Appointment.txt", ios::in | ios::binary);
    Appointment s2;

    cout << "Content of appointment file that inserted" << "\n";
    for (int i = 0; i < count; i++) {
        cout << "Record " << i << endl;
        s2.readAppointment(file, s2);
        cout << "ID: " << s2.Appointment_ID << endl;
        cout << "Date: " << s2.Appointment_Date << endl;
        cout << "Doctor ID: " << s2.Doctor_ID << endl;
        cout << "-------------------------\n";
    }

    file.close();
}
void displayLinkedList_DoctorId() {
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in);
    if (!DoctorLink.is_open()) {
        cout << "Linked List file not found.\n";
        return;
    }

    char doctorID[15];
    char appointmentID[15];
    short nextPointer;

    // Read the content of the linked list file
    while (DoctorLink.read(doctorID, 15)) {
        DoctorLink.read(appointmentID, 15);
        DoctorLink.read((char*)&nextPointer, sizeof(nextPointer));

        cout << "Doctor ID: " << doctorID
             << ", Appointment ID: " << appointmentID
             << ", Next Pointer: " << nextPointer << endl;
    }
    DoctorLink.close();
}

//

int main() {
    write_Number_of_appointment();
    displaySecondary_DoctorId();
    cout<<"----------------------------\n";
    displayLinkedList_DoctorId();
    return 0;
}
