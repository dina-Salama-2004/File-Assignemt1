#include <iostream>
#include <fstream>
#include <cstring>
#include <strstream>

using namespace std;

int getRecordCount(const char* filename, int recordSize) {
    fstream file(filename, ios::binary | ios::in);
    if (!file.is_open()) {
        cout << "File not found: " << filename << endl;
        return 0;
    }
    file.seekg(0, ios::end);
    int fileSize = file.tellg();
    file.close();
    return fileSize / recordSize;
}
//---------------------- Primary index using the Appointment ID (for Appointments data file).

void Insert_Appointment_ID_Sorted(char id[] , short offset, int &count_id){
    fstream primary("primary_Index.txt", ios::out | ios::binary |ios::in );
    int New_App_id = 0;
    for(int i=0 ; id[i] != '\0'; i++){
        New_App_id *=10;
        New_App_id +=(id[i] - '0');
    }
    int existing_id = 0;
    short off = 0;
    bool find_position = false;

    if(count_id == 0){
        primary.write((char*)&New_App_id, sizeof(New_App_id));
        primary.write((char*)&offset, sizeof(offset));
        count_id++;
        cout << New_App_id << offset << "the only one--------------" << endl;
    }
    else{
        primary.read((char*)&existing_id, sizeof(existing_id));
        while(primary.good()){
            if(existing_id > New_App_id){
                find_position= true;
                primary.seekg(-4,ios::cur);
                off = primary.tellg();
                break;
            }
            primary.seekg(2, ios::cur);
            primary.read((char*)&existing_id, sizeof(existing_id));
        }
        primary.close();
        primary.open("primary_Index.txt", ios::out | ios::binary |ios::in  );

        if(!find_position){
            primary.seekg(count_id*6,ios::beg);
            primary.write((char*)&New_App_id, sizeof(int));
            primary.write((char*)&offset, sizeof(short));
            count_id++;
            cout << New_App_id << offset << "--------------" << endl;


        }
        else{
            primary.seekg((count_id-1)*6);
            int endNum;
            short endOf;
            primary.read((char*)&endNum, sizeof (endNum));
            primary.read((char*)&endOf, sizeof (endOf));
            primary.seekg(off);

            while(primary.good()){//1 2 -3 -3 4 5
                int num1;short num1_Of;
                int num2;short num2_Of;
                primary.read((char*)&num1, sizeof (num1));
                primary.read((char*)&num1_Of, sizeof (num1_Of));

                primary.read((char*)&num2, sizeof (num2));
                primary.read((char*)&num2_Of, sizeof (num2_Of));

                primary.seekg(-6,ios::cur);
                primary.write((char*)&num1, sizeof (num1));
                primary.write((char*)&num1_Of, sizeof (num1_Of));
            }
            primary.close();
            primary.open("primary_Index.txt", ios::out | ios::binary |ios::in );

            primary.seekg(0,ios::end);
            primary.write((char*)&endNum, sizeof (endNum));
            primary.write((char*)&endOf, sizeof (endOf));
            primary.seekg(off);
            primary.write((char*)&New_App_id, sizeof (New_App_id));
            primary.write((char*)&offset, sizeof (off));
            count_id++;
            cout << New_App_id << offset << "--------------" << endl;
        }
    }

    primary.close();
}

//---------------------- Primary index using the Doctor ID (for Doctors data file).
void Insert_Doctor_ID_Sorted(char id[], short offset, int &count_id) {
    fstream primary("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);
    int New_Doctor_id = 0;
    for (int i = 0; id[i] != '\0'; i++) {
        New_Doctor_id *= 10;
        New_Doctor_id += (id[i] - '0');
    }

    int existing_id = 0;
    short off = 0;
    bool find_position = false;

    if (count_id == 0) {
        primary.write((char *)&New_Doctor_id, sizeof(New_Doctor_id));
        primary.write((char *)&offset, sizeof(offset));
        count_id++;
    } else {
        primary.read((char *)&existing_id, sizeof(existing_id));
        while (primary.good()) {
            if (existing_id > New_Doctor_id) {
                find_position = true;
                primary.seekg(-4, ios::cur);
                off = primary.tellg();
                break;
            }
            primary.seekg(2, ios::cur);
            primary.read((char *)&existing_id, sizeof(existing_id));
        }
        primary.close();
        primary.open("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);

        if (!find_position) {
            primary.seekg(count_id * 6, ios::beg);
            primary.write((char *)&New_Doctor_id, sizeof(int));
            primary.write((char *)&offset, sizeof(short));
            count_id++;
        } else {
            primary.seekg((count_id - 1) * 6);
            int endNum;
            short endOf;
            primary.read((char *)&endNum, sizeof(endNum));
            primary.read((char *)&endOf, sizeof(endOf));
            primary.seekg(off);
            while (primary.good()) {
                int num1;
                short num1_Of;
                int num2;
                short num2_Of;
                primary.read((char *)&num1, sizeof(num1));
                primary.read((char *)&num1_Of, sizeof(num1_Of));

                primary.read((char *)&num2, sizeof(num2));
                primary.read((char *)&num2_Of, sizeof(num2_Of));

                primary.seekg(-6, ios::cur);
                primary.write((char *)&num1, sizeof(num1));
                primary.write((char *)&num1_Of, sizeof(num1_Of));
            }
            primary.close();
            primary.open("doctor_primary_Index.txt", ios::out | ios::binary | ios::in);
            primary.seekg(0, ios::end);
            primary.write((char *)&endNum, sizeof(endNum));
            primary.write((char *)&endOf, sizeof(endOf));
            primary.seekg(off);
            primary.write((char *)&New_Doctor_id, sizeof(New_Doctor_id));
            primary.write((char *)&offset, sizeof(off));
            count_id++;
        }
    }

    primary.close();
}

//---------------------- Secondary index using the Doctor ID (for the Appointments data file).
void displaySecondary_DoctorId() {
    fstream DoctorSec("SecondaryIndexForDoctor.txt", ios::binary | ios::in);
    if (!DoctorSec.is_open()) {
        cout << "Secondary Index file not found.\n";
        return;
    }

    char doctorID[15];
    short linkedListPointer;

    // Read the content of the secondary index file
    while (DoctorSec.read(doctorID, 15)) {
        DoctorSec.read((char*)&linkedListPointer, sizeof(linkedListPointer));
        cout << "Doctor ID: " << doctorID
             << ", Linked List Pointer: " << linkedListPointer << endl;
    }

    DoctorSec.close();
}
void displayLinkedList_DoctorId() {
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in);
    if (!DoctorLink.is_open()) {
        cout << "Linked List file not found.\n";
        return;
    }

    char doctorID[15];
    char appointmentID[15];
    short nextPointer;

    // Read the content of the linked list file
    while (DoctorLink.read(doctorID, 15)) {
        DoctorLink.read(appointmentID, 15);
        DoctorLink.read((char*)&nextPointer, sizeof(nextPointer));

        cout << "Doctor ID: " << doctorID
             << ", Appointment ID: " << appointmentID
             << ", Next Pointer: " << nextPointer << endl;
    }

    DoctorLink.close();
}

bool doctorIdExists(fstream &DoctorSec, const char *Doctor_ID) {
    short first = 0, last = getRecordCount("SecondaryIndexForDoctor.txt", 17) - 1; // Record size is 17
    char temp[15];
    short mid;
    bool found = false;

    while (first <= last && !found) {
        mid = (first + last) / 2;

        DoctorSec.seekg(mid * 17, ios::beg);
        DoctorSec.read(temp, 15);
        int cmpResult = strcmp(temp, Doctor_ID);

        if (cmpResult == 0) {
            found = true;
        } else if (cmpResult > 0) {
            last = mid - 1;
        } else {
            first = mid + 1;
        }
    }

    return found;
}
void addToLinkedList_DoctorId(const char *Doctor_ID, const char *Appointment_ID) {
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in | ios::out);
    DoctorLink.seekg(0, ios::end);
    DoctorLink.write(Doctor_ID, 15);
    DoctorLink.write(Appointment_ID, 15);
    short nega = -1;  // End of the linked list
    DoctorLink.write((char*)&nega, sizeof(nega));
    DoctorLink.close();
}
void insert_secondary_DoctorId(char Doctor_ID[15], char Appointment_ID[15]) {
    fstream DoctorSec("SecondaryIndexForDoctor.txt", ios::binary | ios::in | ios::out);
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in | ios::out);

    bool found = doctorIdExists(DoctorSec, Doctor_ID);

    if (!found) {

        int totalEntries = getRecordCount("SecondaryIndexForDoctor.txt", 17);
        int insertPosition = totalEntries;

        char temp[15];
        short linkedListPointer;
        for (int i = 0; i < totalEntries; i++) {
            DoctorSec.seekg(i * 17, ios::beg);
            DoctorSec.read(temp, 15);
            int cmpResult = strcmp(temp, Doctor_ID);
            if (cmpResult > 0) {
                insertPosition = i;
                break;
            }
        }

        DoctorSec.seekg(0, ios::end);
        int fileSize = DoctorSec.tellg();
        char *buffer = new char[fileSize];
        DoctorSec.seekg(0, ios::beg);
        DoctorSec.read(buffer, fileSize);

        DoctorSec.close();
        DoctorSec.open("SecondaryIndexForDoctor.txt", ios::binary | ios::out);


        linkedListPointer = getRecordCount("LLIndexForDoctor.txt", 32);
        DoctorSec.seekp(insertPosition * 17, ios::beg);
        DoctorSec.write(Doctor_ID, 15);
        DoctorSec.write((char*)&linkedListPointer, sizeof(linkedListPointer));


        DoctorSec.write(buffer + insertPosition * 17, fileSize - insertPosition * 17);
        delete[] buffer;

        addToLinkedList_DoctorId(Doctor_ID, Appointment_ID);
    } else {
        // Doctor ID exists, update the linked list
        DoctorLink.seekg(0, ios::end);
        int fileSize = DoctorLink.tellg();
        int entrySize = 32;  // Size of each record (doctorID + appointmentID + nextPointer)
        int recordCount = fileSize / entrySize;

        for (int i = recordCount - 1; i >= 0; i--) {
            DoctorLink.seekg(i * entrySize, ios::beg);
            char doctorID[15];
            char appointmentID[15];
            short nextPointer;

            DoctorLink.read(doctorID, 15);
            DoctorLink.read(appointmentID, 15);
            DoctorLink.read((char*)&nextPointer, sizeof(nextPointer));

            if (strcmp(doctorID, Doctor_ID) == 0) {
                short newPointer = recordCount; // Update to the next appointment record
                DoctorLink.seekp(i * entrySize + 30, ios::beg);
                DoctorLink.write((char*)&newPointer, sizeof(newPointer));
                break;
            }
        }

        // Add the appointment to the linked list
        addToLinkedList_DoctorId(Doctor_ID, Appointment_ID);
        DoctorSec.close();
        DoctorLink.close();
    }
}

// ---------------------- Secondary index using the Doctor Name (for the Doctors data file).
// Function to check if the Doctor Name already exists in the secondary index
bool doctorNameExists(fstream &DoctorSec, const char *Doctor_Name) {
    short first = 0, last = getRecordCount("SecondaryIndexForDoctor.txt", 17) - 1; // Record size is 17
    char temp[30]; // Doctor Name length is 30
    short mid;
    bool found = false;

    while (first <= last && !found) {
        mid = (first + last) / 2;

        DoctorSec.seekg(mid * 17, ios::beg);  // We use 17 since each record is DoctorName (30) + Linked List Pointer (short)
        DoctorSec.read(temp, 30);
        int cmpResult = strcmp(temp, Doctor_Name);

        if (cmpResult == 0) {
            found = true;
        } else if (cmpResult > 0) {
            last = mid - 1;
        } else {
            first = mid + 1;
        }
    }

    return found;
}

// Function to add Doctor Name to the linked list (LLIndexForDoctor.txt)
void addToLinkedList_DoctorName(const char *Doctor_Name, const char *Doctor_ID) {
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in | ios::out);
    DoctorLink.seekg(0, ios::end);
    DoctorLink.write(Doctor_ID, 15); // Doctor ID is 15 characters
    short nega = -1;  // End of the linked list
    DoctorLink.write((char*)&nega, sizeof(nega));
    DoctorLink.close();
}

// Function to insert secondary Doctor Name index and update the linked list
void insert_secondary_DoctorName(char Doctor_Name[30], char Doctor_ID[15]) {
    fstream DoctorSec("SecondaryIndexForDoctor.txt", ios::binary | ios::in | ios::out);
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in | ios::out);

    bool found = doctorNameExists(DoctorSec, Doctor_Name);  // Check if the Doctor Name already exists

    if (!found) {
        // Doctor Name does not exist, insert in the secondary index
        int totalEntries = getRecordCount("SecondaryIndexForDoctor.txt", 17);  // Record size is 17
        int insertPosition = totalEntries;

        char temp[30];  // Temporary array to hold Doctor Name
        short linkedListPointer;
        for (int i = 0; i < totalEntries; i++) {
            DoctorSec.seekg(i * 17, ios::beg);  // Record size is 17 (30 for name + 2 for pointer)
            DoctorSec.read(temp, 30);  // Read the Doctor Name
            int cmpResult = strcmp(temp, Doctor_Name);
            if (cmpResult > 0) {
                insertPosition = i;
                break;
            }
        }

        DoctorSec.seekg(0, ios::end);
        int fileSize = DoctorSec.tellg();
        char *buffer = new char[fileSize];
        DoctorSec.seekg(0, ios::beg);
        DoctorSec.read(buffer, fileSize);

        DoctorSec.close();
        DoctorSec.open("SecondaryIndexForDoctor.txt", ios::binary | ios::out);

        // Insert the Doctor Name and the linked list pointer
        linkedListPointer = getRecordCount("LLIndexForDoctor.txt", 60);  // Each record in LLIndexForDoctor.txt is 60 bytes (DoctorID + Pointer)
        DoctorSec.seekp(insertPosition * 17, ios::beg);
        DoctorSec.write(Doctor_Name, 30);
        DoctorSec.write((char*)&linkedListPointer, sizeof(linkedListPointer));  // Write the linked list pointer

        DoctorSec.write(buffer + insertPosition * 17, fileSize - insertPosition * 17);  // Write the rest of the data
        delete[] buffer;

        // Add the new entry to the linked list
        addToLinkedList_DoctorName(Doctor_Name, Doctor_ID);
    } else {
        // Doctor Name exists, update the linked list
        DoctorLink.seekg(0, ios::end);
        int fileSize = DoctorLink.tellg();
        int entrySize = 60;  // Size of each record in the linked list (DoctorID + Pointer)
        int recordCount = fileSize / entrySize;

        for (int i = recordCount - 1; i >= 0; i--) {
            DoctorLink.seekg(i * entrySize, ios::beg);
            char doctorID[15];
            short nextPointer;

            DoctorLink.read(doctorID, 15);
            DoctorLink.read((char*)&nextPointer, sizeof(nextPointer));

            if (strcmp(doctorID, Doctor_ID) == 0) {
                short newPointer = recordCount;  // Update to the next doctor record
                DoctorLink.seekp(i * entrySize + 15, ios::beg);  // Pointer is at byte 15
                DoctorLink.write((char*)&newPointer, sizeof(newPointer));
                break;
            }
        }

        // Add the doctor to the linked list
        addToLinkedList_DoctorName(Doctor_Name, Doctor_ID);
        DoctorSec.close();
        DoctorLink.close();
    }
}


void displayLinkedList_DoctorName() {
    fstream DoctorLink("LLIndexForDoctor.txt", ios::binary | ios::in);
    if (!DoctorLink.is_open()) {
        cout << "Linked List file not found.\n";
        return;
    }

    char doctorID[15];       // Doctor ID length is 15
    short nextPointer;

    cout << "Displaying Linked List for Doctor Name:\n";
    cout << "Doctor ID         | Next Pointer\n";
    cout << "----------------------------\n";

    // Read the content of the linked list file
    while (DoctorLink.read(doctorID, 15)) {
        DoctorLink.read((char*)&nextPointer, sizeof(nextPointer));

        // Display Doctor ID and its Next Pointer
        cout << doctorID << "       | " << nextPointer << endl;
    }

    DoctorLink.close();
}
void displaySecondary_DoctorName() {
    fstream DoctorSec("SecondaryIndexForDoctor.txt", ios::binary | ios::in);
    if (!DoctorSec.is_open()) {
        cout << "Secondary Index file not found.\n";
        return;
    }

    char doctorName[30];  // Doctor Name length is 30
    short linkedListPointer;

    cout << "Displaying Secondary Index for Doctor Name:\n";
    cout << "Doctor Name               | Linked List Pointer\n";
    cout << "---------------------------------------------\n";

    // Read the content of the secondary index file
    while (DoctorSec.read(doctorName, 30)) {
        DoctorSec.read((char*)&linkedListPointer, sizeof(linkedListPointer));

        // Display Doctor Name and its Linked List Pointer
        cout << doctorName << "     | " << linkedListPointer << endl;
    }

    DoctorSec.close();
}

//------------------------------------------------------------

// Class for Appointment record
class Appointment {
public:
    char Appointment_ID[15];
    char Appointment_Date[30];
    char Doctor_ID[15];

    const static int maxRecordSize = 1000;

    void writeAppointment(fstream &file, Appointment &s) {
        char record[maxRecordSize];
        strcpy(record, s.Appointment_ID);
        strcat(record, "|");
        strcat(record, s.Appointment_Date);
        strcat(record, "|");
        strcat(record, s.Doctor_ID);
        strcat(record, "|");

        short length = strlen(record);

        file.write((char*)&length, sizeof(length));
        file.write(record, length);
    }

    void readAppointment(fstream &file, Appointment &s) {
        short length;
        file.read((char*)&length, sizeof(length));
        char* record = new char[length];

        file.read(record, length);
        istrstream strbuff(record);
        strbuff >> s;
    }

    friend istream& operator>>(istream& file, Appointment &s) {
        file.getline(s.Appointment_ID, 15, '|');
        file.getline(s.Appointment_Date, 30, '|');
        file.getline(s.Doctor_ID, 15, '|');
        return file;
    }
};

//class doctor
class Doctor {
public:
    char Doctor_ID[15];
    char Doctor_Name[30];
    char Doctor_Address[30];

    const static int maxRecordSize = 1000;

    void writeDoctor(fstream &file, Doctor &doc) {
        char record[maxRecordSize];
        strcpy(record, doc.Doctor_ID);
        strcat(record, "|");
        strcat(record, doc.Doctor_Name);
        strcat(record, "|");
        strcat(record, doc.Doctor_Address);
        strcat(record, "|");

        short length = strlen(record);
        file.write((char*)&length, sizeof(length));
        file.write(record, length);
    }
    void readDoctor(fstream &file, Doctor &doc) {
        short length;
        file.read((char *)&length, sizeof(length));
        char *record = new char[length];

        file.read(record, length);

        istrstream strbuff(record);
        strbuff >> doc;
        // delete[] record;
    }

    friend istream &operator>>(istream &file, Doctor &doc) {
        file.getline(doc.Doctor_ID, 15, '|');
        file.getline(doc.Doctor_Name, 30, '|');
        file.getline(doc.Doctor_Address, 30, '|');
        return file;
    }
};

int main() {

//
//    read appointemnt

//    ios_base::sync_with_stdio(false);
//    cin.tie(NULL);
//    int count_id = 0;
//
//    fstream file("Appointment.txt", ios::out | ios::trunc);
//    cout << "Enter # of Appointments you want to enter" << endl;
//    int count;
//    cin >> count;
//    cin.ignore();
//
//    Appointment record;
//    for (int i = 0; i < count; i++) {
//        cout << "ID: " << endl;
//        cin >> record.Appointment_ID;
//        cout << "Date: " << endl;
//        cin.ignore();
//        cin.getline(record.Appointment_Date, 30);
//        cout << "Doctor ID: " << endl;
//        cin >> record.Doctor_ID;
//        cout << "Offset = " << file.tellp() << endl;
//        Insert_Appointment_ID_Sorted(record.Appointment_ID,file.tellp(), count_id);
//        insert_secondary_DoctorId(record.Doctor_ID, record.Appointment_ID);
//
//        record.writeAppointment(file, record);
//    }
//    file.close();
//
//    file.open("Appointment.txt", ios::in | ios::binary);
//    Appointment s2;
//    cout<<"appointment file \n";
//    for (int i = 0; i < count; i++) {
//        s2.readAppointment(file, s2);
//        cout << "ID: " << s2.Appointment_ID << " Date: " << s2.Appointment_Date << " Doctor ID: " << s2.Doctor_ID << endl;
//    }
//    file.close();
//    cout<<"secondary index \n";
//    displaySecondary_DoctorId();
//    cout<<"linked list  index \n";
//    // Display the content of the linked list (Doctor ID -> Appointment ID -> Next Pointer)
//    displayLinkedList_DoctorId();





//
//    read doctor
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int count_id = 0;
    fstream file("Doctor.txt", ios::out | ios::trunc);

    cout <<"Enter number of doctors to add: "<<endl;
    int count;
    cin >> count;
    cin.ignore();

    Doctor record;
    for (int i = 0; i < count; i++) {
        cout << "Doctor ID: "<<endl;
        cin >> record.Doctor_ID;
        cout << "Doctor Name: "<<endl;
        cin.ignore();
        cin.getline(record.Doctor_Name, 30);
        cout << "Doctor Address: "<<endl;
        cin.getline(record.Doctor_Address, 30);

        cout << "Offset = " << file.tellp() << endl;
        Insert_Doctor_ID_Sorted(record.Doctor_ID, file.tellp(), count_id);
        insert_secondary_DoctorName(record.Doctor_ID, record.Doctor_Name);
        record.writeDoctor(file, record);
    }
    file.close();

    file.open("Doctor.txt", ios::in | ios::binary);
    Doctor doc;
    for (int i = 0; i < count; i++) {
        doc.readDoctor(file, doc);
        cout << "Doctor ID: " << doc.Doctor_ID << endl;
        cout << "Doctor Name: " << doc.Doctor_Name << endl;
        cout << "Doctor Address: " << doc.Doctor_Address << endl;
    }

//    cout << "Secondary index for Doctor Name: " << endl;
//    displaySecondary_DoctorName();
//
//    cout << "Linked list index for Doctor Name: " << endl;
//    displayLinkedList_DoctorName();
    file.close();






    return 0;
}
